from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.models import User
from petnica.models import Profile
from django.contrib.auth import authenticate, login, logout
from django.http import JsonResponse

# @login_required
def home(request):
    profile = None
    if request.user.is_authenticated:
        profile = get_object_or_404(Profile, user=request.user)
    return render(request, 'home.html', {'profile': profile})

def login_page(request):
    if request.user.is_authenticated:
        return render(request, 'home.html')
    return render(request, 'registration/login.html')

def register_page(request):
    if request.user.is_authenticated:
        return render(request, 'home.html')
    return render(request, 'registration/register.html')

def login_user(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        username = email.split('@')[0]
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return JsonResponse({'status': 'success'})
        else:
            return JsonResponse({'status': 'fail', 'message': 'Invalid credentials'}, status=401)
    return JsonResponse({'status': 'fail', 'message': 'Invalid request method'}, status=405)

def logout_user(request):
    if request.method == 'POST':
        logout(request)
    return render(request, 'registration/login.html')

def register_user(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        username = email.split('@')[0]
        password = request.POST.get('password')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        phone = request.POST.get('phone_number')
        phone_number_str = str(phone)
        if User.objects.filter(email=email).exists():
            return JsonResponse({'status': 'fail','message': 'Email already exists'}, status=409)
        
        user = User.objects.create_user(username=username, email=email, password=password, first_name=first_name, last_name=last_name)
        user.save()
        
        profile = Profile.objects.get(user=user)
        profile.phone = phone_number_str
        profile.save()
        
        return JsonResponse({'status': 'success'})
    return render(request, 'login.html')
