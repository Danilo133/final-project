
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.login_page, name='login'),
    path('register/', views.register_page, name='register'),
    path('login_user/', views.login_user, name='login_user'),
    path('logout/', views.logout_user, name='logout'),
    path('register_user/', views.register_user, name='register_user'),
    path('upload/', include('file_upload.urls')),
    path('records/', include('records.urls')),
    # path('accounts/', include('django.contrib.auth.urls')),
    path('admin/', admin.site.urls),
]
